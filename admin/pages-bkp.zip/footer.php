<!-- FOOTER -->
<script>
var _system_script          =   '<?php echo $script;?>';
</script>
<script type="text/javascript" src="js/validation/jquery.validate.min.js" ></script>
<script type="text/javascript" src="js/validation/additional-methods.min.js" ></script>
<script type="text/javascript" src="js/form-validation.js" ></script>
<div style="clear:both;"></div>
<div id="footer">
	<?= $COPYRIGHT_TEXT_ADMIN; ?>
</div>
