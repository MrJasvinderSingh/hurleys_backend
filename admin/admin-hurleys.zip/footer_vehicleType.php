<!-- FOOTER -->
<script>
var _system_script          =   '<?php echo $script;?>';
</script>
<div id="footer">
	<?= $COPYRIGHT_TEXT_ADMIN; ?>
</div>